import firebase from "firebase"

var firebaseConfig = {
    apiKey: "AIzaSyCpRLJZmDpq15eyEEX1h4gvm0kVeQeMjWo",
    authDomain: "jwellery-5017b.firebaseapp.com",
    projectId: "jwellery-5017b",
    storageBucket: "jwellery-5017b.appspot.com",
    messagingSenderId: "499980897150",
    appId: "1:499980897150:web:78b9063cf39d22e060c12f",
    measurementId: "G-Z2TH9DSJME"
  };

    firebase.initializeApp(firebaseConfig);

export default firebase;