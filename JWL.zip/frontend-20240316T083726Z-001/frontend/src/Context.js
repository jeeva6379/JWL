import React from 'react'

export const ContextData = React.createContext();